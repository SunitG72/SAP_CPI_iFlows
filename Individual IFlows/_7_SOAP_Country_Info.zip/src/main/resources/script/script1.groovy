import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.io.Reader
 
def Message processData(Message message) {
    // 1. Get the payload as a Reader to enable streaming (Memory safe)
    def reader = message.getBody(Reader)
    
    // Safety check: ensure the reader isn't null
    if (reader != null) {
        
        // 2. Parse the XML stream using the correctly imported groovy.util.XmlSlurper
        def root = new XmlSlurper().parse(reader)
        
        // 3. Search deeply ('**') for the tag name, ignoring namespaces completely
        def countryValue = root.'**'.find { it.name() == 'CountryISOCodeResult' }?.text()
        
        // 4. Save the extracted value to an Exchange Property named "CapitalCity"
        if (countryValue) {
            message.setProperty("countryCode", countryValue)
        }
    }
    
    return message
}