import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.io.Reader
 
def Message processData(Message message) {
    def reader = message.getBody(Reader)
    if (reader != null) {
        def root = new XmlSlurper().parse(reader)
        def resultNode = root.'**'.find { it.name() == 'FullCountryInfoResult' }
        
        if (resultNode) {
            message.setProperty("Country_ISOCode", resultNode.'*'.find { it.name() == 'sISOCode' }?.text())
            message.setProperty("Country_Name", resultNode.'*'.find { it.name() == 'sName' }?.text())
            message.setProperty("Country_CapitalCity", resultNode.'*'.find { it.name() == 'sCapitalCity' }?.text())
            message.setProperty("Country_PhoneCode", resultNode.'*'.find { it.name() == 'sPhoneCode' }?.text())
            message.setProperty("Country_ContinentCode", resultNode.'*'.find { it.name() == 'sContinentCode' }?.text())
            message.setProperty("Country_CurrencyISOCode", resultNode.'*'.find { it.name() == 'sCurrencyISOCode' }?.text())
            message.setProperty("Country_FlagURL", resultNode.'*'.find { it.name() == 'sCountryFlag' }?.text())
            
            def firstLanguageNode = resultNode.'**'.find { it.name() == 'tLanguage' }
            if (firstLanguageNode) {
                message.setProperty("Language_ISOCode", firstLanguageNode.'*'.find { it.name() == 'sISOCode' }?.text())
                message.setProperty("Language_Name", firstLanguageNode.'*'.find { it.name() == 'sName' }?.text())
            }
        }
    }
    return message
}