import com.sap.gateway.ip.core.customdev.util.Message;
 
def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    if (body != null) {
        body = body.replaceAll(/<\?xml[^>]*\?>/, "");
        message.setBody(body);
    }
    
    def dbRow = message.getProperty("OriginalDatabaseRow");
    if (dbRow != null) {
        String dbRowStr = dbRow.toString();
        dbRowStr = dbRowStr.replaceAll(/<\?xml[^>]*\?>/, "");
        message.setProperty("OriginalDatabaseRow", dbRowStr);
    }
    
    return message;
}