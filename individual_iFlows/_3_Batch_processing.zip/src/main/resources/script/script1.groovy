import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
 
def Message processData(Message message) {
    def bodyReader = message.getBody(java.io.Reader)
    def properties = message.getProperties()
    
    def thresholdProp = properties.get("highAmountThreshold")
    BigDecimal highAmountThreshold = thresholdProp ? new BigDecimal(thresholdProp.toString()) : new BigDecimal("10000")
 
    def parsedXml = new XmlSlurper().parse(bodyReader)
    
    def invoiceNode = parsedXml.name() == 'Invoices' ? parsedXml.Invoice : parsedXml
    
    def invoiceId = invoiceNode.InvoiceId.text()
    def customerName = invoiceNode.CustomerName.text()
    def region = invoiceNode.Region.text().toUpperCase()
    
    def amountStr = invoiceNode.Amount.text()
    BigDecimal amount = amountStr ? new BigDecimal(amountStr) : BigDecimal.ZERO
 
    def severity = "NORMAL"
    if (!invoiceId || !customerName || !region || !amountStr) {
        severity = "INVALID"
    } else if (region != "IN" && region != "US") {
        severity = "INVALID"
    } else if (amount > highAmountThreshold) {
        severity = "HIGH"
    }
 
    message.setProperty("invoiceId", invoiceId)
    message.setProperty("region", region)
    message.setProperty("severity", severity)
    
    def emailBody = """\
    Invoice ID: ${invoiceId ?: 'MISSING'}
    Customer: ${customerName ?: 'MISSING'}
    Internal - General Use
    Region: ${region ?: 'MISSING'}
    Amount: ${amountStr ?: 'MISSING'}
    Severity: ${severity}
    """.stripIndent().trim()
 
    message.setBody(emailBody)
    message.setHeader("Content-Type", "text/plain")
 
    return message
}