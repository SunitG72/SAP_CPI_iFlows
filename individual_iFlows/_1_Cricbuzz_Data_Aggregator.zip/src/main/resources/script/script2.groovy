import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)

    def xmlParser = new XmlParser(false, false).parseText(body)
    def sw = new StringWriter()
    def printer = new XmlNodePrinter(new PrintWriter(sw))
    printer.setPreserveWhitespace(true)
    printer.setIndent("    ") // 4 spaces
    printer.print(xmlParser)

    message.setBody(sw.toString())
    return message
}
