import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def jsonObj = jsonSlurper.parseText(body)

    def sanitizeKey
    sanitizeKey = { obj ->
        if (obj instanceof Map) {
            def newMap = [:]
            obj.each { k, v ->
                def safeKey = k.replaceAll("[^A-Za-z0-9_.-]", "_")
                newMap[safeKey] = sanitizeKey(v)
            }
            return newMap
        } else if (obj instanceof List) {
            return obj.collect { sanitizeKey(it) }
        } else {
            return obj
        }
    }

    def cleanedJson = sanitizeKey(jsonObj)
    def newJson = JsonOutput.toJson(cleanedJson)

    message.setBody(newJson)
    return message
}
