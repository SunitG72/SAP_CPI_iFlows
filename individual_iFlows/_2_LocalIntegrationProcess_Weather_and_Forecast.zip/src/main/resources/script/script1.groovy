// import com.sap.gateway.ip.core.customdev.util.Message
 
// def Message processData(Message message) {
//     def body = message.getBody(java.lang.String)
    
//     if (body != null) {
//         body = body.replace("\"1h\":", "\"one_h\":")
//         message.setBody(body)
//     }
    
//     return message
// }

import com.sap.gateway.ip.core.customdev.util.Message
 
def Message processData(Message message) {
    def body = message.getBody(String.class)
    if (body) {
        def numMap = [
            '0':'zero', '1':'one', '2':'two', '3':'three', '4':'four',
            '5':'five', '6':'six', '7':'seven', '8':'eight', '9':'nine'
        ]
        body = body.replaceAll(/"(\d)([^"]*)"\s*:/) { match, digit, rest ->
            def word = numMap[digit] ?: digit
            return '"' + word + '_' + rest + '":'
        }
        message.setBody(body)
    }
    return message
}