import com.sap.gateway.ip.core.customdev.util.Message
 
def Message processData(Message message) {
    
    def properties = message.getProperties()
    
    String inputString = properties.get("CityName")
    
    if (inputString != null) {
        String formattedString = inputString.trim()
        if (!formattedString.isEmpty()) {
            formattedString = formattedString.replaceAll(/\s+/, "+")
        }
        message.setProperty("FormattedCityName", formattedString)
    }
    return message
}
