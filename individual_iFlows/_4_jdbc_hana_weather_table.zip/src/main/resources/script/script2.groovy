import com.sap.gateway.ip.core.customdev.util.Message
 
def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    
    if (body != null) {
        body = body.replace("\"1h\":", "\"one_h\":")
        message.setBody(body)
    }
    
    return message
}